from django.http import HttpResponse
from django.shortcuts import render, redirect
from django.contrib.auth.hashers import make_password, check_password
from django.db.models import Sum
from datetime import datetime, timedelta
import datetime
from .models import Dcuser
from .forms import LoginForm
from board.models import Board_server
from board.models import Basic_server
from board.models import MdBoard_server
from board.models import AyBoard_server
from board.models import PgBoard_server
# Create your views here.



def calculate_last_month_total_ea(boards, server):
    current_month = datetime.date.today().month
    last_month = current_month - 1 if current_month > 1 else 12
    current_year = datetime.date.today().year
    last_month_year = current_year if last_month != 12 else current_year - 1

    last_month_total_ea = boards.filter(server=server,
                                        registered_dttm__year=last_month_year,
                                        registered_dttm__month=last_month).aggregate(total_ea=Sum('ea')).get('total_ea')
    return last_month_total_ea or 0

def home(request):
    gs_boards = Board_server.objects.all().order_by('-vendor')
    md_boards = MdBoard_server.objects.all().order_by('-vendor')
    pg_boards = PgBoard_server.objects.all().order_by('-vendor')
    ay_boards = AyBoard_server.objects.all().order_by('-vendor')
    basic_servers = Basic_server.objects.all().order_by('-vendor')
    
    # 해당 서버명에 대한 총 EA 계산
    for gs_board in gs_boards:
        gs_board.total_ea = gs_boards.filter(server=gs_board.server).aggregate(total_ea=Sum('ea')).get('total_ea')
        md_board_total_ea = md_boards.filter(server=gs_board.server).aggregate(total_ea=Sum('ea')).get('total_ea')
        pg_board_total_ea = pg_boards.filter(server=gs_board.server).aggregate(total_ea=Sum('ea')).get('total_ea')
        ay_board_total_ea = ay_boards.filter(server=gs_board.server).aggregate(total_ea=Sum('ea')).get('total_ea')

        # 현재총 EA 값을 합산
        gs_board.total_ea = gs_board.total_ea or 0
        gs_board.total_ea += md_board_total_ea or 0
        gs_board.total_ea += pg_board_total_ea or 0
        gs_board.total_ea += ay_board_total_ea or 0

        # 이전 달의 총 수량값 계산
        gs_board.last_month_total_ea = calculate_last_month_total_ea(gs_boards, gs_board.server)
        gs_board.last_month_total_ea += calculate_last_month_total_ea(md_boards, gs_board.server)
        gs_board.last_month_total_ea += calculate_last_month_total_ea(pg_boards, gs_board.server)
        gs_board.last_month_total_ea += calculate_last_month_total_ea(ay_boards, gs_board.server)



    
    return render(request, 'main.html', {'gs_boards': gs_boards, 'md_boards': md_boards, 'pg_boards' : pg_boards, 'ay_boards': ay_boards,  'basic_servers': basic_servers })





def logout(request):
    if request.session.get('user'):
        del(request.session['user'])

    return redirect('/')

 

def login(request):
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            request.session['user'] = form.user_id
            return redirect('/')
    else:
        form = LoginForm()

    return render(request, 'login.html', {'form': form})


def register(request):
    if request.method == 'GET':
        return render(request, 'register.html')
    elif request.method == 'POST':
        username = request.POST.get('username', None)
        password = request.POST.get('password', None)
        re_password = request.POST.get('re-password', None)

        res_data = {}

        if not (username and password and re_password):
            res_data['error'] = '모든값을 입력'
        elif password != re_password:
             res_data['error'] = '비밀번호가 다릅니다'
        else:
            fcuser = Dcuser(
                username=username,
                password=make_password(password)
            )

            fcuser.save()
            return redirect('/dcuser/login/')



        return render(request, 'register.html', res_data)  