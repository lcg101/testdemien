from django.contrib import admin
from .models import Dcuser
# Register your models here.


class DcuserAdmin(admin.ModelAdmin):
    list_display = ('username', 'password', 'registered_dttm')

admin.site.register(Dcuser, DcuserAdmin)