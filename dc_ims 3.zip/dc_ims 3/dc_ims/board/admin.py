from django.contrib import admin
from .models import Basic_server
from .models import Board 
from .models import Board_server
from .models import Md_Board 
from .models import MdBoard_server
from .models import Pg_Board
from .models import PgBoard_server
from .models import Ay_Board
from .models import AyBoard_server

# Register your models here.
# demien:dlckdrms15

class BoardAdmin(admin.ModelAdmin):
    list_display = ('title','ea','errorea' ,'vendor','hwpart','writer','registered_dttm')

admin.site.register(Board, BoardAdmin)

class Board_serverAdmin(admin.ModelAdmin):
    list_display = ('server', 'ea','writer','registered_dttm' ,'vendor')

admin.site.register(Board_server, Board_serverAdmin)

#----------MD

class Md_BoardAdmin(admin.ModelAdmin):
    list_display = ('title','ea','errorea','vendor','writer','registered_dttm')

admin.site.register(Md_Board, Md_BoardAdmin)

class MdBoard_serverAdmin(admin.ModelAdmin):
    list_display = ('server', 'barcode' ,'status', 'writer','registered_dttm' ,'vendor')

admin.site.register(MdBoard_server, MdBoard_serverAdmin)

#--------PG

class Pg_BoardAdmin(admin.ModelAdmin):
    list_display = ('title','ea','errorea','vendor','writer','registered_dttm')

admin.site.register(Pg_Board, Pg_BoardAdmin)

class PgBoard_serverAdmin(admin.ModelAdmin):
    list_display = ('server', 'barcode' ,'status', 'writer','registered_dttm' ,'vendor')

admin.site.register(PgBoard_server, PgBoard_serverAdmin)
#------AY

class Ay_BoardAdmin(admin.ModelAdmin):
    list_display = ('title','ea','errorea','vendor','writer','registered_dttm')

admin.site.register(Ay_Board, Ay_BoardAdmin)

class AyBoard_serverAdmin(admin.ModelAdmin):
    list_display = ('server', 'barcode' ,'status', 'writer','registered_dttm' ,'vendor')

admin.site.register(AyBoard_server, AyBoard_serverAdmin)

#------------skylake

class Basic_serverAdmin(admin.ModelAdmin):
    list_display = ('server', 'vendor', 'ea')
admin.site.register(Basic_server, Basic_serverAdmin)