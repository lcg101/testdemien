from difflib import restore
from django.db.models import Q
from django.shortcuts import render
from django.shortcuts import render, redirect
from django.core.paginator import Paginator
from django.contrib import messages
from django.utils import timezone
from django.http import Http404
from dcuser.models import Dcuser
from django.contrib import messages

from .models import Basic_server
from .models import Board 
from .models import Board_server
from .models import Md_Board 
from .models import MdBoard_server
from .models import Ay_Board
from .models import AyBoard_server
from .models import Pg_Board
from .models import PgBoard_server

from .forms import BasicserverForm
from .forms import Basic_serverUpdate
from .forms import BoardForm
from .forms import BoardUpdate
from .forms import Board_serverUpdate
from .forms import BoardServerForm
from .forms import MdboardForm
from .forms import MdboardUpdate
from .forms import MdBoardServerForm
from .forms import MdBoard_serverUpdate
from .forms import AyboardForm
from .forms import AyboardUpdate
from .forms import AyBoardServerForm
from .forms import AyBoard_serverUpdate
from .forms import PgboardForm
from .forms import PgboardUpdate
from .forms import PgBoardServerForm
from .forms import PgBoard_serverUpdate
# Create your views here.

#========================================================GS===============================================================

def board_detail(request, pk):  # 목록 자세히 보는구간
    try:
        board = Board.objects.get(pk=pk)
    except Board.DoesNotExist:
        raise Http404('파트를 찾을 수 없습니다.')
        
    return render(request, 'board_detail.html', {'board': board})

def board_delete(request, pk): # 삭제구간
    board = Board.objects.get(pk=pk)
    board.delete()

    return redirect('/board/list/')


def board_update(request, pk): # 수정하는
    if not request.session.get('user'):
        return redirect('/dcuser/login/')

    board = Board.objects.get(pk=pk)
    if request.method == 'POST':
        form = BoardUpdate(request.POST,instance= board )
        if form.is_valid():
            user_id = request.session.get('user')
            dcuser = Dcuser.objects.get(pk=user_id)
            board.title = form.cleaned_data['title']
            board.contents = form.cleaned_data['contents']
            board.ea = form.cleaned_data['ea']
            board.errorea = form.cleaned_data['errorea']
            board.vendor = form.cleaned_data['vendor']
            board.hwpart = form.cleaned_data['hwpart']
            board.registered_dttm = timezone.datetime.now()
            board.writer = dcuser
            board.save()
            
            if board.hwpart == 'MEM':
                return redirect('/board/allmemlist/')
            elif board.hwpart == 'SSD':
                return redirect('/board/allssdlist/')
            elif board.hwpart == 'NVME':
                return redirect('/board/allnvmelist/')
            elif board.hwpart == 'HDD':
                return redirect('/board/allhddlist/')
       
    else:
        form = BoardUpdate(instance= board)

    return render(request, 'board_update.html',{'form': form})


def board_write(request): # 작성
    if not request.session.get('user'): # 사용자 인증이 안되어있을경우 인증화면으로 
        return redirect('/dcuser/login/')

    if request.method == 'POST': 
        form = BoardForm(request.POST)
        if form.is_valid():
            user_id = request.session.get('user')
            dcuser = Dcuser.objects.get(pk=user_id)

            board = Board()
            board.title = form.cleaned_data['title']
            board.contents = form.cleaned_data['contents']
            board.errorea = form.cleaned_data['errorea']
            board.ea = form.cleaned_data['ea']
            board.vendor = form.cleaned_data['vendor']
            board.hwpart = form.cleaned_data['hwpart']
            board.writer = dcuser
            board.save()

            if board.hwpart == 'MEM':
                return redirect('/board/allmemlist/')
            elif board.hwpart == 'SSD':
                return redirect('/board/allssdlist/')
            elif board.hwpart == 'NVME':
                return redirect('/board/allnvmelist/')
            elif board.hwpart == 'HDD':
                return redirect('/board/allhddlist/')
            
    else:    
        form = BoardForm()
    
    return render(request, 'board_write.html', {'form': form})

def board_list(request): # 전체 목록 확인
    all_boards = Board.objects.all().order_by('-vendor')  #('-id') -> ('-vendor')로 변경시 벤더사 기준으로 변환함
    page = int(request.GET.get('p', 1))
    paginator = Paginator(all_boards, 100)

    boards = paginator.get_page(page)
    return render(request, 'board_list.html', {'boards': boards})

def board_memlist(request): # MEM 목록 확인
    all_boards = Board.objects.all().order_by('-vendor')
    page = int(request.GET.get('p', 1))
    paginator = Paginator(all_boards, 100)

    boards = paginator.get_page(page)
    return render(request, 'board_memlist.html', {'boards': boards})

def board_ssdlist(request): # SSD 목록 확인
    all_boards = Board.objects.all().order_by('-vendor')
    page = int(request.GET.get('p', 1))
    paginator = Paginator(all_boards, 100)

    boards = paginator.get_page(page)
    return render(request, 'board_ssdlist.html', {'boards': boards})

def board_nvmelist(request): # NVME 목록 확인
    all_boards = Board.objects.all().order_by('-vendor')
    page = int(request.GET.get('p', 1))
    paginator = Paginator(all_boards, 100)

    boards = paginator.get_page(page)
    return render(request, 'board_nvmelist.html', {'boards': boards})

def board_hddlist(request): # HDD 목록 확인
    all_boards = Board.objects.all().order_by('-vendor')
    page = int(request.GET.get('p', 1))
    paginator = Paginator(all_boards, 100)

    boards = paginator.get_page(page)
    return render(request, 'board_hddlist.html', {'boards': boards})


def board_search(request): # 검색 구간
    all_boards = Board.objects.all().order_by('-vendor')

    q = request.POST.get('q', "")

    if q:
        boards = all_boards.filter(title__icontains=q)
        return render(request, 'board_search.html',{'boards':boards, 'q':q})
    else:
        return render(request, 'board_search.html')

#--------서버

def board_serverwrite(request): # 서버작성
    if not request.session.get('user'): # 사용자 인증이 안되어있을경우 인증화면으로 
        return redirect('/dcuser/login/')

    if request.method == 'POST': 
        forms = BoardServerForm(request.POST)
        if forms.is_valid():
            user_id = request.session.get('user')
            dcuser = Dcuser.objects.get(pk=user_id)

            board = Board_server()
            board.server = forms.cleaned_data['server']
            board.ea = forms.cleaned_data['ea']
            board.contents = forms.cleaned_data['contents']
            board.vendor = forms.cleaned_data['vendor']
            board.writer = dcuser
            board.save()

            return redirect('/board/serverlist/')
    else:    
        forms = BoardServerForm()
    
    return render(request, 'board_serverwrite.html', {'forms': forms})

def board_serverupdate(request, pk): # 서버수정
    if not request.session.get('user'):
        return redirect('/dcuser/login/')

    board = Board_server.objects.get(pk=pk)
    if request.method == 'POST':
        forms = Board_serverUpdate(request.POST,instance= board )
        if forms.is_valid():
            user_id = request.session.get('user')
            dcuser = Dcuser.objects.get(pk=user_id)

            board.server = forms.cleaned_data['server']
            board.ea = forms.cleaned_data['ea']
            board.contents = forms.cleaned_data['contents']
            #board.barcode = forms.cleaned_data['barcode']
            #board.status = forms.cleaned_data['status']
            board.vendor = forms.cleaned_data['vendor']
            board.registered_dttm = timezone.datetime.now()
            board.writer = dcuser
            board.save()
            return redirect('/board/serverlist/')
       
    else:
        form = Board_serverUpdate(instance= board)

    return render(request, 'board_serverupdate.html',{'form': form})

def board_serverdetail(request, pk):  # 목록 자세히 보는구간
    try:
        board = Board_server.objects.get(pk=pk)
    except Board_server.DoesNotExist:
        raise Http404('파트를 찾을 수 없습니다.')
        
    return render(request, 'board_serverdetail.html', {'board': board})

def board_serverlist(request): # 서버 목록확인
    all_boards = Board_server.objects.all().order_by('-vendor')
    page = int(request.GET.get('p', 1))
    paginator = Paginator(all_boards, 100)

    boards = paginator.get_page(page)

    return render(request, 'board_serverlist.html', {'boards': boards})

def board_serversearch(request): # 서버 검색 구간
    all_boards = Board_server.objects.all().order_by('-vendor')

    q = request.POST.get('q', "")

    if q:
        boards = all_boards.filter(server__icontains=q)
        return render(request, 'board_serversearch.html',{'boards':boards, 'q':q})
    else:
        return render(request, 'board_serverearch.html')
    
def board_serverdelete(request, pk): # 삭제구간
    board = Board_server.objects.get(pk=pk)
    board.delete()

    return redirect('/board/serverlist/')
#----------





#======================================================MD======================================================

def mdboard_list(request): # 목록 확인
    all_boards = Md_Board.objects.all().order_by('-id')
    page = int(request.GET.get('p', 1))
    paginator = Paginator(all_boards, 100)

    boards = paginator.get_page(page)
    return render(request, 'Mdboard_list.html', {'boards': boards})

def mdboard_memlist(request): # MEM 목록 확인
    all_boards = Md_Board.objects.all().order_by('-id')
    page = int(request.GET.get('p', 1))
    paginator = Paginator(all_boards, 100)

    boards = paginator.get_page(page)
    return render(request, 'Mdboard_memlist.html', {'boards': boards})

def mdboard_ssdlist(request): # SSD 목록 확인
    all_boards = Md_Board.objects.all().order_by('-id')
    page = int(request.GET.get('p', 1))
    paginator = Paginator(all_boards, 100)

    boards = paginator.get_page(page)
    return render(request, 'Mdboard_ssdlist.html', {'boards': boards})

def mdboard_nvmelist(request): # NVME 목록 확인
    all_boards = Md_Board.objects.all().order_by('-id')
    page = int(request.GET.get('p', 1))
    paginator = Paginator(all_boards, 100)

    boards = paginator.get_page(page)
    return render(request, 'Mdboard_nvmelist.html', {'boards': boards})

def mdboard_hddlist(request): # HDD 목록 확인
    all_boards = Md_Board.objects.all().order_by('-id')
    page = int(request.GET.get('p', 1))
    paginator = Paginator(all_boards, 100)

    boards = paginator.get_page(page)
    return render(request, 'Mdboard_hddlist.html', {'boards': boards})


def mdboard_write(request): # 작성
    if not request.session.get('user'):
        return redirect('/dcuser/login/')

    if request.method == 'POST': 
        form = MdboardForm(request.POST)
        if form.is_valid():
            user_id = request.session.get('user')
            dcuser = Dcuser.objects.get(pk=user_id)

            board = Md_Board()
            board.title = form.cleaned_data['title']
            board.contents = form.cleaned_data['contents']
            board.ea = form.cleaned_data['ea']
            board.errorea = form.cleaned_data['errorea']
            board.vendor = form.cleaned_data['vendor']
            board.hwpart = form.cleaned_data['hwpart']
            board.writer = dcuser
            board.save()

            if board.hwpart == 'MEM':
                return redirect('/board/allmemlist/')
            elif board.hwpart == 'SSD':
                return redirect('/board/allssdlist/')
            elif board.hwpart == 'NVME':
                return redirect('/board/allnvmelist/')
            elif board.hwpart == 'HDD':
                return redirect('/board/allhddlist/')
    else:    
        form = MdboardForm()
    
    return render(request, 'Mdboard_write.html', {'form': form})


def mdboard_detail(request, pk):  # 목록 자세히 보는구간
    try:
        board = Md_Board.objects.get(pk=pk)
    except Board.DoesNotExist:
        raise Http404('파트를 찾을 수 없습니다.')

    return render(request, 'Mdboard_detail.html', {'board': board})

def mdboard_delete(request, pk): # 삭제구간
    board = Md_Board.objects.get(pk=pk)
    board.delete()

    return redirect('/board/mdlist/')

def mdboard_update(request, pk): # 수정하는
    if not request.session.get('user'): 
        return redirect('/dcuser/login/')

    board = Md_Board.objects.get(pk=pk)
    if request.method == 'POST':
        form = MdboardUpdate(request.POST,instance= board )
        if form.is_valid():
            board.title = form.cleaned_data['title']
            board.contents = form.cleaned_data['contents']
            board.ea = form.cleaned_data['ea']
            board.errorea = form.cleaned_data['errorea']
            board.vendor = form.cleaned_data['vendor']
            board.hwpart = form.cleaned_data['hwpart']
            board.registered_dttm = timezone.datetime.now()
            board.save()
            
            if board.hwpart == 'MEM':
                return redirect('/board/allmemlist/')
            elif board.hwpart == 'SSD':
                return redirect('/board/allssdlist/')
            elif board.hwpart == 'NVME':
                return redirect('/board/allnvmelist/')
            elif board.hwpart == 'HDD':
                return redirect('/board/allhddlist/')
       
    else:
        form = BoardUpdate(instance= board)

    return render(request, 'Mdboard_update.html',{'form': form})

def mdboard_search(request): # 검색 구간
    all_boards = Md_Board.objects.all().order_by('-id')

    q = request.POST.get('q', "")

    if q:
        boards = all_boards.filter(title__icontains=q)
        return render(request, 'Mdboard_search.html',{'boards':boards, 'q':q})
    else:
        return render(request, 'Mdboard_search.html')

#-------------MD 서버
def mdboard_serverwrite(request): # 서버작성
    if not request.session.get('user'): # 사용자 인증이 안되어있을경우 인증화면으로 
        return redirect('/dcuser/login/')

    if request.method == 'POST': 
        forms = MdBoardServerForm(request.POST)
        if forms.is_valid():
            user_id = request.session.get('user')
            dcuser = Dcuser.objects.get(pk=user_id)

            board = MdBoard_server()
            board.server = forms.cleaned_data['server']
            board.contents = forms.cleaned_data['contents']
            board.ea = forms.cleaned_data['ea']
            #board.barcode = forms.cleaned_data['barcode']
            #board.status = forms.cleaned_data['status']
            board.vendor = forms.cleaned_data['vendor']
            board.writer = dcuser
            board.save()

            return redirect('/board/mdserverlist/')
    else:    
        forms = MdBoardServerForm()
    
    return render(request, 'Mdboard_serverwrite.html', {'forms': forms})

def mdboard_serverupdate(request, pk): # 서버수정
    if not request.session.get('user'):
        return redirect('/dcuser/login/')

    board = MdBoard_server.objects.get(pk=pk)
    if request.method == 'POST':
        forms = MdBoard_serverUpdate(request.POST,instance= board )
        if forms.is_valid():
            user_id = request.session.get('user')
            dcuser = Dcuser.objects.get(pk=user_id)

            board.server = forms.cleaned_data['server']
            board.contents = forms.cleaned_data['contents']
            board.ea = forms.cleaned_data['ea']
            #board.barcode = forms.cleaned_data['barcode']
            #board.status = forms.cleaned_data['status']
            board.vendor = forms.cleaned_data['vendor']
            board.registered_dttm = timezone.datetime.now()
            board.writer = dcuser
            board.save()
            return redirect('/board/mdserverlist/')
       
    else:
        form = MdBoard_serverUpdate(instance= board)

    return render(request, 'Mdboard_serverupdate.html',{'form': form})

def mdboard_serverdetail(request, pk):  # 서버목록 자세히 보는구간
    try:
        board = MdBoard_server.objects.get(pk=pk)
    except MdBoard_server.DoesNotExist:
        raise Http404('파트를 찾을 수 없습니다.')
        
    return render(request, 'Mdboard_serverdetail.html', {'board': board})

def mdboard_serverlist(request): # 서버 목록확인
    all_boards = MdBoard_server.objects.all().order_by('-vendor')
    page = int(request.GET.get('p', 1))
    paginator = Paginator(all_boards, 100)

    boards = paginator.get_page(page)
    return render(request, 'Mdboard_serverlist.html', {'boards': boards})

def mdboard_serversearch(request): # 서버 검색 구간
    all_boards = MdBoard_server.objects.all().order_by('-id')

    q = request.POST.get('q', "")

    if q:
        boards = all_boards.filter(server__icontains=q)
        return render(request, 'Mdboard_serversearch.html',{'boards':boards, 'q':q})
    else:
        return render(request, 'Mdboard_serverearch.html')
    
def mdboard_serverdelete(request, pk): # 서버 삭제구간
    board = MdBoard_server.objects.get(pk=pk)
    board.delete()

    return redirect('/board/mdserverlist/')


#--------------


# ======================================================AY======================================================

def ayboard_list(request): # 목록 확인
    all_boards = Ay_Board.objects.all().order_by('-id')
    page = int(request.GET.get('p', 1))
    paginator = Paginator(all_boards, 100)

    boards = paginator.get_page(page)
    return render(request, 'Ayboard_list.html', {'boards': boards})

def ayboard_memlist(request): # MEM 목록 확인
    all_boards = Ay_Board.objects.all().order_by('-id')
    page = int(request.GET.get('p', 1))
    paginator = Paginator(all_boards, 100)

    boards = paginator.get_page(page)
    return render(request, 'Ayboard_memlist.html', {'boards': boards})

def ayboard_ssdlist(request): # SSD 목록 확인
    all_boards = Ay_Board.objects.all().order_by('-id')
    page = int(request.GET.get('p', 1))
    paginator = Paginator(all_boards, 100)

    boards = paginator.get_page(page)
    return render(request, 'Ayboard_ssdlist.html', {'boards': boards})

def ayboard_nvmelist(request): # NVME 목록 확인
    all_boards = Ay_Board.objects.all().order_by('-id')
    page = int(request.GET.get('p', 1))
    paginator = Paginator(all_boards, 100)

    boards = paginator.get_page(page)
    return render(request, 'Ayboard_nvmelist.html', {'boards': boards})

def ayboard_hddlist(request): # HDD 목록 확인
    all_boards = Ay_Board.objects.all().order_by('-id')
    page = int(request.GET.get('p', 1))
    paginator = Paginator(all_boards, 100)

    boards = paginator.get_page(page)
    return render(request, 'Ayboard_hddlist.html', {'boards': boards})


def ayboard_write(request): # 작성
    if not request.session.get('user'):
        return redirect('/dcuser/login/')

    if request.method == 'POST': 
        form = AyboardForm(request.POST)
        if form.is_valid():
            user_id = request.session.get('user')
            dcuser = Dcuser.objects.get(pk=user_id)

            board = Ay_Board()
            board.title = form.cleaned_data['title']
            board.contents = form.cleaned_data['contents']
            board.ea = form.cleaned_data['ea']
            board.errorea = form.cleaned_data['errorea']
            board.vendor = form.cleaned_data['vendor']
            board.hwpart = form.cleaned_data['hwpart']
            board.writer = dcuser
            board.save()

            if board.hwpart == 'MEM':
                return redirect('/board/allmemlist/')
            elif board.hwpart == 'SSD':
                return redirect('/board/allssdlist/')
            elif board.hwpart == 'NVME':
                return redirect('/board/allnvmelist/')
            elif board.hwpart == 'HDD':
                return redirect('/board/allhddlist/')
    else:    
        form = AyboardForm()
    
    return render(request, 'Ayboard_write.html', {'form': form})


def ayboard_detail(request, pk):  # 목록 자세히 보는구간
    try:
        board = Ay_Board.objects.get(pk=pk)
    except Board.DoesNotExist:
        raise Http404('파트를 찾을 수 없습니다.')

    return render(request, 'Ayboard_detail.html', {'board': board})

def ayboard_delete(request, pk): # 삭제구간
    board = Ay_Board.objects.get(pk=pk)
    board.delete()

    return redirect('/board/aylist/')

def ayboard_update(request, pk): # 수정하는
    if not request.session.get('user'): 
        return redirect('/dcuser/login/')

    board = Ay_Board.objects.get(pk=pk)
    if request.method == 'POST':
        form = AyboardUpdate(request.POST,instance= board )
        if form.is_valid():
            board.title = form.cleaned_data['title']
            board.contents = form.cleaned_data['contents']
            board.ea = form.cleaned_data['ea']
            board.errorea = form.cleaned_data['errorea']
            board.vendor = form.cleaned_data['vendor']
            board.hwpart = form.cleaned_data['hwpart']
            board.registered_dttm = timezone.datetime.now()
            board.save()
            
            if board.hwpart == 'MEM':
                return redirect('/board/allmemlist/')
            elif board.hwpart == 'SSD':
                return redirect('/board/allssdlist/')
            elif board.hwpart == 'NVME':
                return redirect('/board/allnvmelist/')
            elif board.hwpart == 'HDD':
                return redirect('/board/allhddlist/')
       
    else:
        form = BoardUpdate(instance= board)

    return render(request, 'Ayboard_update.html',{'form': form})

def ayboard_search(request): # 검색 구간
    all_boards = Ay_Board.objects.all().order_by('-id')

    q = request.POST.get('q', "")

    if q:
        boards = all_boards.filter(title__icontains=q)
        return render(request, 'Ayboard_search.html',{'boards':boards, 'q':q})
    else:
        return render(request, 'Ayboard_search.html')
    

#-------------AY 서버

def ayboard_serverwrite(request): # 서버작성
    if not request.session.get('user'): # 사용자 인증이 안되어있을경우 인증화면으로 
        return redirect('/dcuser/login/')

    if request.method == 'POST': 
        forms = AyBoardServerForm(request.POST)
        if forms.is_valid():
            user_id = request.session.get('user')
            dcuser = Dcuser.objects.get(pk=user_id)

            board = AyBoard_server()
            board.server = forms.cleaned_data['server']
            board.contents = forms.cleaned_data['contents']
            board.ea = forms.cleaned_data['ea']
            #board.barcode = forms.cleaned_data['barcode']
            #board.status = forms.cleaned_data['status']
            board.vendor = forms.cleaned_data['vendor']
            board.writer = dcuser
            board.save()

            return redirect('/board/ayserverlist/')
    else:    
        forms = AyBoardServerForm()
    
    return render(request, 'Ayboard_serverwrite.html', {'forms': forms})

def ayboard_serverupdate(request, pk): # 서버수정
    if not request.session.get('user'):
        return redirect('/dcuser/login/')

    board = AyBoard_server.objects.get(pk=pk)
    if request.method == 'POST':
        forms = AyBoard_serverUpdate(request.POST,instance= board )
        if forms.is_valid():
            user_id = request.session.get('user')
            dcuser = Dcuser.objects.get(pk=user_id)

            board.server = forms.cleaned_data['server']
            board.contents = forms.cleaned_data['contents']
            board.ea = forms.cleaned_data['ea']
            #board.barcode = forms.cleaned_data['barcode']
            #board.status = forms.cleaned_data['status']
            board.vendor = forms.cleaned_data['vendor']
            board.registered_dttm = timezone.datetime.now()
            board.writer = dcuser
            board.save()
            return redirect('/board/ayserverlist/')
       
    else:
        form = AyBoard_serverUpdate(instance= board)

    return render(request, 'Ayboard_serverupdate.html',{'form': form})

def ayboard_serverdetail(request, pk):  # 서버목록 자세히 보는구간
    try:
        board = AyBoard_server.objects.get(pk=pk)
    except AyBoard_server.DoesNotExist:
        raise Http404('파트를 찾을 수 없습니다.')
        
    return render(request, 'Ayboard_serverdetail.html', {'board': board})

def ayboard_serverlist(request): # 서버 목록확인
    all_boards = AyBoard_server.objects.all().order_by('-vendor')
    page = int(request.GET.get('p', 1))
    paginator = Paginator(all_boards, 100)

    boards = paginator.get_page(page)
    return render(request, 'Ayboard_serverlist.html', {'boards': boards})

def ayboard_serversearch(request): # 서버 검색 구간
    all_boards = AyBoard_server.objects.all().order_by('-id')
    q = request.POST.get('q', "")

    if q:
        boards = all_boards.filter(server__icontains=q)
        return render(request, 'Ayboard_serversearch.html',{'boards':boards, 'q':q})
    else:
        return render(request, 'Ayboard_serverearch.html')
    
def ayboard_serverdelete(request, pk): # 서버 삭제구간
    board = AyBoard_server.objects.get(pk=pk)
    board.delete()

    return redirect('/board/ayserverlist/')





#======================================================PG======================================================




def pgboard_list(request): # 목록 확인
    all_boards = Pg_Board.objects.all().order_by('-id')
    page = int(request.GET.get('p', 1))
    paginator = Paginator(all_boards, 100)

    boards = paginator.get_page(page)
    return render(request, 'Pgboard_list.html', {'boards': boards})

def pgboard_memlist(request): # MEM 목록 확인
    all_boards = Pg_Board.objects.all().order_by('-id')
    page = int(request.GET.get('p', 1))
    paginator = Paginator(all_boards, 100)

    boards = paginator.get_page(page)
    return render(request, 'Pgboard_memlist.html', {'boards': boards})

def pgboard_ssdlist(request): # SSD 목록 확인
    all_boards = Pg_Board.objects.all().order_by('-id')
    page = int(request.GET.get('p', 1))
    paginator = Paginator(all_boards, 100)

    boards = paginator.get_page(page)
    return render(request, 'Pgboard_ssdlist.html', {'boards': boards})

def pgboard_nvmelist(request): # NVME 목록 확인
    all_boards = Pg_Board.objects.all().order_by('-id')
    page = int(request.GET.get('p', 1))
    paginator = Paginator(all_boards, 100)

    boards = paginator.get_page(page)
    return render(request, 'Pgboard_nvmelist.html', {'boards': boards})

def pgboard_hddlist(request): # hdd 목록 확인
    all_boards = Pg_Board.objects.all().order_by('-id')
    page = int(request.GET.get('p', 1))
    paginator = Paginator(all_boards, 100)

    boards = paginator.get_page(page)
    return render(request, 'Pgboard_hddlist.html', {'boards': boards})


def pgboard_write(request): # 작성
    if not request.session.get('user'):
        return redirect('/dcuser/login/')

    if request.method == 'POST': 
        form = PgboardForm(request.POST)
        if form.is_valid():
            user_id = request.session.get('user')
            dcuser = Dcuser.objects.get(pk=user_id)

            board = Pg_Board()
            board.title = form.cleaned_data['title']
            board.contents = form.cleaned_data['contents']
            board.ea = form.cleaned_data['ea']
            board.errorea = form.cleaned_data['errorea']
            board.vendor = form.cleaned_data['vendor']
            board.hwpart = form.cleaned_data['hwpart']
            board.writer = dcuser
            board.save()

            if board.hwpart == 'MEM':
                return redirect('/board/allmemlist/')
            elif board.hwpart == 'SSD':
                return redirect('/board/allssdlist/')
            elif board.hwpart == 'NVME':
                return redirect('/board/allnvmelist/')
            elif board.hwpart == 'HDD':
                return redirect('/board/allhddlist/')
    else:    
        form = PgboardForm()
    
    return render(request, 'Pgboard_write.html', {'form': form})


def pgboard_detail(request, pk):  # 목록 자세히 보는구간
    try:
        board = Pg_Board.objects.get(pk=pk)
    except Board.DoesNotExist:
        raise Http404('파트를 찾을 수 없습니다.')

    return render(request, 'Pgboard_detail.html', {'board': board})

def pgboard_delete(request, pk): # 삭제구간
    board = Pg_Board.objects.get(pk=pk)
    board.delete()

    return redirect('/board/pglist/')

def pgboard_update(request, pk): # 수정하는
    if not request.session.get('user'): 
        return redirect('/dcuser/login/')

    board = Pg_Board.objects.get(pk=pk)
    if request.method == 'POST':
        form = PgboardUpdate(request.POST,instance= board )
        if form.is_valid():
            board.title = form.cleaned_data['title']
            board.contents = form.cleaned_data['contents']
            board.ea = form.cleaned_data['ea']
            board.errorea = form.cleaned_data['errorea']
            board.vendor = form.cleaned_data['vendor']
            board.hwpart = form.cleaned_data['hwpart']
            board.registered_dttm = timezone.datetime.now()
            board.save()
            
            if board.hwpart == 'MEM':
                return redirect('/board/allmemlist/')
            elif board.hwpart == 'SSD':
                return redirect('/board/allssdlist/')
            elif board.hwpart == 'NVME':
                return redirect('/board/allnvmelist/')
            elif board.hwpart == 'HDD':
                return redirect('/board/allhddlist/')
       
    else:
        form = BoardUpdate(instance= board)

    return render(request, 'Pgboard_update.html',{'form': form})


def pgboard_search(request): # 검색 구간
    all_boards = Pg_Board.objects.all().order_by('-id')

    q = request.POST.get('q', "")

    if q:
        boards = all_boards.filter(title__icontains=q)
        return render(request, 'Pgboard_search.html',{'boards':boards, 'q':q})
    else:
        return render(request, 'Pgboard_search.html')
    

#-------------PG 서버
def pgboard_serverwrite(request): # 서버작성
    if not request.session.get('user'): # 사용자 인증이 안되어있을경우 인증화면으로 
        return redirect('/dcuser/login/')

    if request.method == 'POST': 
        forms = PgBoardServerForm(request.POST)
        if forms.is_valid():
            user_id = request.session.get('user')
            dcuser = Dcuser.objects.get(pk=user_id)

            board = PgBoard_server()
            board.server = forms.cleaned_data['server']
            board.contents = forms.cleaned_data['contents']
            board.ea = forms.cleaned_data['ea']
            #board.barcode = forms.cleaned_data['barcode']
            #board.status = forms.cleaned_data['status']
            board.vendor = forms.cleaned_data['vendor']
            board.writer = dcuser
            board.save()

            return redirect('/board/pgserverlist/')
    else:    
        forms = PgBoardServerForm()
    
    return render(request, 'Pgboard_serverwrite.html', {'forms': forms})

def pgboard_serverupdate(request, pk): # 서버수정
    if not request.session.get('user'):
        return redirect('/dcuser/login/')

    board = PgBoard_server.objects.get(pk=pk)
    if request.method == 'POST':
        forms = PgBoard_serverUpdate(request.POST,instance= board )
        if forms.is_valid():
            user_id = request.session.get('user')
            dcuser = Dcuser.objects.get(pk=user_id)

            board.server = forms.cleaned_data['server']
            board.contents = forms.cleaned_data['contents']
            board.ea = forms.cleaned_data['ea']
            #board.barcode = forms.cleaned_data['barcode']
            #board.status = forms.cleaned_data['status']
            board.vendor = forms.cleaned_data['vendor']
            board.registered_dttm = timezone.datetime.now()
            board.writer = dcuser
            board.save()
            return redirect('/board/pgserverlist/')
       
    else:
        form = PgBoard_serverUpdate(instance= board)

    return render(request, 'Pgboard_serverupdate.html',{'form': form})

def pgboard_serverdetail(request, pk):  # 서버목록 자세히 보는구간
    try:
        board = PgBoard_server.objects.get(pk=pk)
    except PgBoard_server.DoesNotExist:
        raise Http404('파트를 찾을 수 없습니다.')
        
    return render(request, 'Pgboard_serverdetail.html', {'board': board})

def pgboard_serverlist(request): # 서버 목록확인
    all_boards = PgBoard_server.objects.all().order_by('-vendor')
    page = int(request.GET.get('p', 1))
    paginator = Paginator(all_boards, 100)

    boards = paginator.get_page(page)
    return render(request, 'Pgboard_serverlist.html', {'boards': boards})

def pgboard_serversearch(request): # 서버 검색 구간
    all_boards = PgBoard_server.objects.all().order_by('-id')
    q = request.POST.get('q', "")

    if q:
        boards = all_boards.filter(server__icontains=q)
        return render(request, 'Pgboard_serversearch.html',{'boards':boards, 'q':q})
    else:
        return render(request, 'Pgboard_serverearch.html')
    
def pgboard_serverdelete(request, pk): # 서버 삭제구간
    board = PgBoard_server.objects.get(pk=pk)
    board.delete()

    return redirect('/board/pgserverlist/')



# ---------------- skylake 서버 목록 --------------

def basic_serverwrite(request): # 서버작성
    if not request.session.get('user'): # 사용자 인증이 안되어있을경우 인증화면으로 
        return redirect('/dcuser/login/')

    if request.method == 'POST': 
        forms = BasicserverForm(request.POST)
        if forms.is_valid():
            user_id = request.session.get('user')
            dcuser = Dcuser.objects.get(pk=user_id)

            board = Basic_server()
            board.server = forms.cleaned_data['server']
            board.ea = forms.cleaned_data['ea']
            board.vendor = forms.cleaned_data['vendor']
            board.writer = dcuser
            board.save()

            return redirect('/board/basicserverlist/')
    else:    
        forms = BasicserverForm()
    
    return render(request, 'Basic_serverwrite.html', {'forms': forms})

def basic_serverupdate(request, pk): # 서버수정
    if not request.session.get('user'):
        return redirect('/dcuser/login/')

    board = Basic_server.objects.get(pk=pk)
    if request.method == 'POST':
        forms = Basic_serverUpdate(request.POST,instance= board )
        if forms.is_valid():
            user_id = request.session.get('user')
            dcuser = Dcuser.objects.get(pk=user_id)

            board.server = forms.cleaned_data['server']
            board.ea = forms.cleaned_data['ea']
            board.vendor = forms.cleaned_data['vendor']
            board.registered_dttm = timezone.datetime.now()
            board.writer = dcuser
            board.save()
            return redirect('/board/basicserverlist/')
       
    else:
        form = Basic_serverUpdate(instance= board)

    return render(request, 'Basic_serverupdate.html',{'form': form})

def basic_serverdetail(request, pk):  # 서버목록 자세히 보는구간
    try:
        board = Basic_server.objects.get(pk=pk)
    except Basic_server.DoesNotExist:
        raise Http404('파트를 찾을 수 없습니다.')
        
    return render(request, 'Basic_serverdetail.html', {'board': board})

def basic_serverlist(request): # 서버 목록확인
    all_boards = Basic_server.objects.all().order_by('-vendor')
    page = int(request.GET.get('p', 1))
    paginator = Paginator(all_boards, 100)

    boards = paginator.get_page(page)
    return render(request, 'Basic_serverlist.html', {'boards': boards})

    
def basic_serverdelete(request, pk): # 서버 삭제구간
    board = Basic_server.objects.get(pk=pk)
    board.delete()

    return redirect('/board/basicserverlist/')



## ----------이력페이지--------##
# 노출되어야할거
# 서버명 작성자 해당시간 이슈이력



#####===============######


# 각 부품페이지마다 base.html 생성 할것 
# MEM 전체 
# MEM 페이지 들어올시 세로네비게이션바에 가산,목동,안양,판교  출력될수있게
def allmemlist(request):
    gs_boards = Board_server.objects.all().order_by('-vendor')
    md_boards = MdBoard_server.objects.all().order_by('-vendor')
    pg_boards = PgBoard_server.objects.all().order_by('-vendor')
    ay_boards = AyBoard_server.objects.all().order_by('-vendor')

    return render(request, 'Allmem.html', {'gs_boards': gs_boards, 'md_boards': md_boards, 'pg_boards' : pg_boards, 'ay_boards':ay_boards })



# SSD 전체
# 페이지 들어올시 세로네비게이션바에 가산,목동,안양,판교  출력될수있게
def allssdlist(request):
    gs_boards = Board_server.objects.all().order_by('-vendor')
    md_boards = MdBoard_server.objects.all().order_by('-vendor')
    pg_boards = PgBoard_server.objects.all().order_by('-vendor')
    ay_boards = AyBoard_server.objects.all().order_by('-vendor')

    return render(request, 'Allssd.html', {'gs_boards': gs_boards, 'md_boards': md_boards, 'pg_boards' : pg_boards, 'ay_boards':ay_boards })

# NVME 전체
# 페이지 들어올시 세로네비게이션바에 가산,목동,안양,판교  출력될수있게
def allnvmelist(request):
    gs_boards = Board_server.objects.all().order_by('-vendor')
    md_boards = MdBoard_server.objects.all().order_by('-vendor')
    pg_boards = PgBoard_server.objects.all().order_by('-vendor')
    ay_boards = AyBoard_server.objects.all().order_by('-vendor')

    return render(request, 'Allnvme.html', {'gs_boards': gs_boards, 'md_boards': md_boards, 'pg_boards' : pg_boards, 'ay_boards':ay_boards })

# HDD 전체
# 페이지 들어올시 세로네비게이션바에 가산,목동,안양,판교  출력될수있게
def allhddlist(request):
    gs_boards = Board_server.objects.all().order_by('-vendor')
    md_boards = MdBoard_server.objects.all().order_by('-vendor')
    pg_boards = PgBoard_server.objects.all().order_by('-vendor')
    ay_boards = AyBoard_server.objects.all().order_by('-vendor')

    return render(request, 'Allhdd.html', {'gs_boards': gs_boards, 'md_boards': md_boards, 'pg_boards' : pg_boards, 'ay_boards':ay_boards })
