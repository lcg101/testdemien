
from django import forms
from .models import Basic_server
from .models import Board
from .models import Board_server
from .models import Md_Board
from .models import MdBoard_server
from .models import Ay_Board
from .models import AyBoard_server
from .models import Pg_Board
from .models import PgBoard_server

from django.contrib.auth.hashers import check_password

#---------------------------GS----------------------------------------
class BoardForm(forms.Form):
    title = forms.CharField(error_messages={'required':'제목을 입력해주세요'},max_length=128, label="파트명")
    hwpart = forms.CharField(error_messages={'required' : 'part를 골라주세요'}, label="파트목록")
    vendor = forms.CharField(error_messages={'required':'벤더사를 골라주세요'},label="벤더사")
    ea = forms.CharField(error_messages={'required':'수량을 입력해주세요'},max_length=128,label="활용가능")
    errorea =  forms.CharField(error_messages={'required':'수량을 입력해주세요'},max_length=128,label="장애대처")
    contents = forms.CharField(widget=forms.Textarea ,label="이슈 이력")


class BoardUpdate(forms.ModelForm):
    class Meta:
        model = Board
        fields = ['title','hwpart','vendor', 'ea', 'errorea','contents']


class BoardServerForm(forms.Form):
    server = forms.CharField(max_length=128,label="서버명")
    #barcode = forms.CharField(max_length=128, label="바코드")
    #status = forms.CharField(max_length=128, label="상태")
    ea = forms.CharField(max_length=128, label='총갯수')
    vendor = forms.CharField(error_messages={'required':'벤더사를 골라주세요'},label="벤더사")
    contents = forms.CharField(widget=forms.Textarea ,label="이슈 이력")
  


class Board_serverUpdate(forms.ModelForm):
    class Meta:
        model = Board_server
        fields = ['server','ea', 'vendor','contents']

#----------------------------MD--------------------------------------

class MdboardForm(forms.Form):
    title = forms.CharField(error_messages={'required':'제목을 입력해주세요'},max_length=128, label="파트명")
    hwpart = forms.CharField(error_messages={'required' : 'part를 골라주세요'}, label="파트목록")
    vendor = forms.CharField(error_messages={'required':'벤더사를 골라주세요'},label="벤더사")
    ea = forms.CharField(error_messages={'required':'수량을 입력해주세요'},max_length=128,label="활용가능")
    errorea =  forms.CharField(error_messages={'required':'수량을 입력해주세요'},max_length=128,label="장애대처")
    contents = forms.CharField(widget=forms.Textarea ,label="이슈 이력")

class MdBoardServerForm(forms.Form):
    server = forms.CharField(max_length=128,label="서버명")
    #barcode = forms.CharField(max_length=128, label="바코드")
    #status = forms.CharField(max_length=128, label="상태")
    ea = forms.CharField(max_length=128, label='총갯수')
    vendor = forms.CharField(error_messages={'required':'벤더사를 골라주세요'},label="벤더사")
    contents = forms.CharField(widget=forms.Textarea ,label="이슈 이력")
  
class MdboardUpdate(forms.ModelForm):
    class Meta:
        model = Board
        fields = ['title','hwpart' ,'vendor', 'ea',  'errorea', 'contents']

class MdBoard_serverUpdate(forms.ModelForm):
    class Meta:
        model = Board_server
        fields = ['server','ea', 'vendor','contents']


#---------------------------AY----------------------------------------


class AyboardForm(forms.Form):
    title = forms.CharField(error_messages={'required':'제목을 입력해주세요'},max_length=128, label="파트명")
    hwpart = forms.CharField(error_messages={'required' : 'part를 골라주세요'}, label="파트목록")
    vendor = forms.CharField(error_messages={'required':'벤더사를 골라주세요'},label="벤더사")
    ea = forms.CharField(error_messages={'required':'수량을 입력해주세요'},max_length=128,label="활용가능")
    errorea =  forms.CharField(error_messages={'required':'수량을 입력해주세요'},max_length=128,label="장애대처")
    contents = forms.CharField(widget=forms.Textarea ,label="이슈 이력")

class AyBoardServerForm(forms.Form):
    server = forms.CharField(max_length=128,label="서버명")
    #barcode = forms.CharField(max_length=128, label="바코드")
    #status = forms.CharField(max_length=128, label="상태")
    ea = forms.CharField(max_length=128, label='총갯수')
    vendor = forms.CharField(error_messages={'required':'벤더사를 골라주세요'},label="벤더사")
    contents = forms.CharField(widget=forms.Textarea ,label="이슈 이력")
  
class AyboardUpdate(forms.ModelForm):
    class Meta:
        model = Board
        fields = ['title','hwpart' ,'vendor', 'ea',  'errorea', 'contents']

class AyBoard_serverUpdate(forms.ModelForm):
    class Meta:
        model = Board_server
        fields = ['server','ea', 'vendor','contents']

#---------------------------PG----------------------------------------



class PgboardForm(forms.Form):
    title = forms.CharField(error_messages={'required':'제목을 입력해주세요'},max_length=128, label="파트명")
    hwpart = forms.CharField(error_messages={'required' : 'part를 골라주세요'}, label="파트목록")
    vendor = forms.CharField(error_messages={'required':'벤더사를 골라주세요'},label="벤더사")
    ea = forms.CharField(error_messages={'required':'수량을 입력해주세요'},max_length=128,label="활용가능")
    errorea =  forms.CharField(error_messages={'required':'수량을 입력해주세요'},max_length=128,label="장애대처")
    contents = forms.CharField(widget=forms.Textarea ,label="이슈 이력")

class PgBoardServerForm(forms.Form):
    server = forms.CharField(max_length=128,label="서버명")
    #barcode = forms.CharField(max_length=128, label="바코드")
    #status = forms.CharField(max_length=128, label="상태")
    ea = forms.CharField(max_length=128, label='총갯수')
    vendor = forms.CharField(error_messages={'required':'벤더사를 골라주세요'},label="벤더사")
    contents = forms.CharField(widget=forms.Textarea ,label="이슈 이력")
  
class PgboardUpdate(forms.ModelForm):
    class Meta:
        model = Board
        fields = ['title','hwpart' ,'vendor', 'ea',   'errorea','contents']

class PgBoard_serverUpdate(forms.ModelForm):
    class Meta:
        model = Board_server
        fields = ['server','ea', 'vendor','contents']


#------------skylake 서버

class BasicserverForm(forms.Form):
    server = forms.CharField(max_length=128,label="서버명")
    ea = forms.CharField(max_length=128, label='총갯수')
    vendor = forms.CharField(error_messages={'required':'벤더사를 골라주세요'},label="벤더사")

class Basic_serverUpdate(forms.ModelForm):
    class Meta:
        model = Board_server
        fields = ['server','ea', 'vendor']