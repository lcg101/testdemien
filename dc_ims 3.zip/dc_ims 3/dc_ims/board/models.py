from django.db import models

# Create your models here.

class Board(models.Model):
    title = models.CharField(max_length=128, verbose_name='파트명')
    hwpart = models.CharField(max_length=128,verbose_name='부품', default=False)
    contents = models.TextField(verbose_name='이슈 이력', default = '')
    ea = models.CharField(max_length=255, verbose_name='활용가능')
    errorea = models.CharField(max_length=255, verbose_name='장애대처')
    registered_dttm = models.DateTimeField(auto_now_add='등록시간')
    vendor = models.CharField(max_length=128, verbose_name='벤더사', default=False)
    writer = models.ForeignKey('dcuser.Dcuser', on_delete=models.CASCADE, verbose_name='작성자')
    def __str__(self):
        return self.title

    class Meta:
        db_table = 'dceng_gs_imsboard'
        verbose_name = 'IMS 가산파트'
        verbose_name_plural = 'IMS 가산파트'

class Board_server(models.Model):
    server = models.CharField(max_length=255, verbose_name="서버", default=False)
    status = models.CharField(max_length=255, verbose_name="상태", default=False)
    barcode = models.CharField(max_length=255, verbose_name="바코드", default=False)
    writer = models.ForeignKey('dcuser.Dcuser', on_delete=models.CASCADE, verbose_name='작성자')
    ea = models.CharField(max_length=255, verbose_name='총수량', default=False)
    contents = models.TextField(verbose_name='이슈 이력', default = '')
    registered_dttm = models.DateTimeField(auto_now_add='등록시간')
    vendor = models.CharField(max_length=128, verbose_name='벤더사', default=False)
    
    def __str__(self):
        return self.server
    
    class Meta:
        db_table = 'dceng_gs_ims_server'
        verbose_name = 'IMS 가산 서버'
        verbose_name_plural = 'IMS 가산서버'

#-------------MD


class Md_Board(models.Model):
    title = models.CharField(max_length=128, verbose_name='파트')
    hwpart = models.CharField(max_length=128,verbose_name='부품', default=False)
    contents = models.TextField(verbose_name='이슈 이력', default = '')
    ea = models.CharField(max_length=255, verbose_name='활용가능')
    errorea = models.CharField(max_length=255, verbose_name='장애대처')
    registered_dttm = models.DateTimeField(auto_now_add='등록시간')
    vendor = models.CharField(max_length=128, verbose_name='벤더사', default=False)
    writer = models.ForeignKey('dcuser.Dcuser', on_delete=models.CASCADE, verbose_name='작성자')

    def __str__(self):
        return self.title

    class Meta:
        db_table = 'dceng_md_imsboard'
        verbose_name = 'IMS 목동파트'
        verbose_name_plural = 'IMS 목동파트'

class MdBoard_server(models.Model):
    server = models.CharField(max_length=255, verbose_name="서버", default=False)
    status = models.CharField(max_length=255, verbose_name="상태", default=False)
    ea = models.CharField(max_length=255, verbose_name='총수량', default=False)
    barcode = models.CharField(max_length=255, verbose_name="바코드", default=False)
    writer = models.ForeignKey('dcuser.Dcuser', on_delete=models.CASCADE, verbose_name='작성자')
    contents = models.TextField(verbose_name='이슈 이력', default = '')
    registered_dttm = models.DateTimeField(auto_now_add='등록시간')
    vendor = models.CharField(max_length=128, verbose_name='벤더사', default=False)
    
    def __str__(self):
        return self.server
    
    class Meta:
        db_table = 'dceng_md_ims_server'
        verbose_name = 'IMS 목동 서버'
        verbose_name_plural = 'IMS 목동 서버'


#-------------PG


class Pg_Board(models.Model):
    title = models.CharField(max_length=128, verbose_name='파트')
    hwpart = models.CharField(max_length=128,verbose_name='부품', default=False)
    contents = models.TextField(verbose_name='이슈 이력', default = '')
    ea = models.CharField(max_length=255, verbose_name='활용가능')
    errorea = models.CharField(max_length=255, verbose_name='장애대처')
    registered_dttm = models.DateTimeField(auto_now_add='등록시간')
    vendor = models.CharField(max_length=128, verbose_name='벤더사', default=False)
    writer = models.ForeignKey('dcuser.Dcuser', on_delete=models.CASCADE, verbose_name='작성자')

    def __str__(self):
        return self.title

    class Meta:
        db_table = 'dceng_pg_imsboard'
        verbose_name = 'IMS 판교파트'
        verbose_name_plural = 'IMS 판교파트'

class PgBoard_server(models.Model):
    server = models.CharField(max_length=255, verbose_name="서버", default=False)
    status = models.CharField(max_length=255, verbose_name="상태", default=False)
    ea = models.CharField(max_length=255, verbose_name='총수량', default=False)
    barcode = models.CharField(max_length=255, verbose_name="바코드", default=False)
    writer = models.ForeignKey('dcuser.Dcuser', on_delete=models.CASCADE, verbose_name='작성자')
    contents = models.TextField(verbose_name='이슈 이력', default = '')
    registered_dttm = models.DateTimeField(auto_now_add='등록시간')
    vendor = models.CharField(max_length=128, verbose_name='벤더사', default=False)
    
    def __str__(self):
        return self.server
    
    class Meta:
        db_table = 'dceng_pg_ims_server'
        verbose_name = 'IMS 판교 서버'
        verbose_name_plural = 'IMS 판교 서버'


#-------------AY

class Ay_Board(models.Model):
    title = models.CharField(max_length=128, verbose_name='파트')
    hwpart = models.CharField(max_length=128,verbose_name='부품', default=False)
    contents = models.TextField(verbose_name='이슈 이력', default = '')
    ea = models.CharField(max_length=255, verbose_name='활용가능')
    errorea = models.CharField(max_length=255, verbose_name='장애대처')
    registered_dttm = models.DateTimeField(auto_now_add='등록시간')
    vendor = models.CharField(max_length=128, verbose_name='벤더사', default=False)
    writer = models.ForeignKey('dcuser.Dcuser', on_delete=models.CASCADE, verbose_name='작성자')

    def __str__(self):
        return self.title

    class Meta:
        db_table = 'dceng_ay_imsboard'
        verbose_name = 'IMS 안양파트'
        verbose_name_plural = 'IMS 안양파트'

class AyBoard_server(models.Model):
    server = models.CharField(max_length=255, verbose_name="서버", default=False)
    status = models.CharField(max_length=255, verbose_name="상태", default=False)
    ea = models.CharField(max_length=255, verbose_name='총수량', default=False)
    barcode = models.CharField(max_length=255, verbose_name="바코드", default=False)
    writer = models.ForeignKey('dcuser.Dcuser', on_delete=models.CASCADE, verbose_name='작성자')
    contents = models.TextField(verbose_name='이슈 이력', default = '')
    registered_dttm = models.DateTimeField(auto_now_add='등록시간')
    vendor = models.CharField(max_length=128, verbose_name='벤더사', default=False)
    
    def __str__(self):
        return self.server
    
    class Meta:
        db_table = 'dceng_ay_ims_server'
        verbose_name = 'IMS 안양 서버'
        verbose_name_plural = 'IMS 안양 서버'

class Basic_server(models.Model):
    server = models.CharField(max_length=255, verbose_name="서버", default=False)
    ea = models.CharField(max_length=255, verbose_name='기본수량', default=False)
    writer = models.ForeignKey('dcuser.Dcuser', on_delete=models.CASCADE, verbose_name='작성자')
    registered_dttm = models.DateTimeField(auto_now_add='등록시간')
    vendor = models.CharField(max_length=128, verbose_name='벤더사', default=False)
    
    def __str__(self):
        return self.server
    
    class Meta:
        db_table = 'dceng_Skylake_server'
        verbose_name = 'IMS Skylake 서버'
        verbose_name_plural = 'IMS Skylake 서버'