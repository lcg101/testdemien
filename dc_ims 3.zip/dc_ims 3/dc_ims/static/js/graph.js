document.addEventListener("DOMContentLoaded", function() {
    const rows = document.querySelectorAll("tbody tr");
    const serverData = [];
    rows.forEach(function(row) {
        const serverNameCell = row.querySelector("td:nth-child(1)");
        const gsEaCell = row.querySelector("td:nth-child(4)");
        const mdEaCell = row.querySelector("td:nth-child(5)");
        const ayEaCell = row.querySelector("td:nth-child(6)");
        const pgEaCell = row.querySelector("td:nth-child(7)");
        const totalEaCell = row.querySelector("td:nth-child(8)");
        const lastMonthTotalEaCell = row.querySelector("td:nth-child(9)");

        const serverName = serverNameCell.textContent.trim();
        const gsEa = parseInt(gsEaCell.textContent.trim());
        const mdEa = parseInt(mdEaCell.textContent.trim());
        const ayEa = parseInt(ayEaCell.textContent.trim());
        const pgEa = parseInt(pgEaCell.textContent.trim());
        const totalEa = parseInt(totalEaCell.textContent.trim());
        const lastMonthTotalEa = parseInt(lastMonthTotalEaCell.textContent.trim());

        serverData.push({ serverName, gsEa, mdEa, ayEa, pgEa, totalEa, lastMonthTotalEa });
    });

    const colors = [
            "rgba(255, 99, 132)",
            "rgba(54, 162, 235)",
            "rgba(255, 206, 86)",
            "rgba(75, 192, 192)",
            "rgba(153, 102, 255)",
            "rgba(255, 159, 64)",
            "rgba(201, 203, 207)",
            "rgba(0, 255, 0)",
            "rgba(0, 0, 255)"
        ];

    const ctx = document.getElementById("eaChart").getContext("2d");
    new Chart(ctx, {
        type: "bar",
        data: {
            labels: serverData.map(data => data.serverName),
            datasets: [
                {
                    label: "총수량",
                    data: serverData.map(data => data.totalEa),
                    backgroundColor: colors,
                    borderColor: colors,
                    borderWidth: 1
                }
            ]
        },
        options: {
            scales: {
                x: {
                    position: "left",
                    grid: {
                        display: false
                    }
                },
                y: {
                    beginAtZero: true
                }
            },
            plugins: {
                datalabels: {
                    anchor: "end",
                    align: "top",
                    formatter: function(value) {
                        return value;
                    }
                }
            }
        },
        plugins: [ChartDataLabels] // chartjs-plugin-datalabels 추가
    });



        

        const differenceData = serverData.map(data => data.totalEa - data.lastMonthTotalEa);
        

        const differenceCtx = document.getElementById("differenceChart").getContext("2d");
        new Chart(differenceCtx, {
            type: "pie",
            data: {
                labels: serverData.map(data => data.serverName),
                datasets: [
                    {
                        data: differenceData,
                        backgroundColor: colors
                    }
                ]
            },
            options: {
                plugins: {
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                var label = context.label || '';
                                var value = context.raw || '';
                                return label + ': ' + value;
                            }
                        }
                    }
                }
            }
        });
    });