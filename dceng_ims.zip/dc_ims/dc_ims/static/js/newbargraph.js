const differenceData = serverData.map(data => data.totalEa - data.lastMonthTotalEa);

const differenceCtx = document.getElementById("differenceChart").getContext("2d");
new Chart(differenceCtx, {
    type: "bar",
    data: {
        labels: serverData.map(data => data.serverName),
        datasets: [
            {
                
                data: differenceData,
                backgroundColor: colors,
                borderColor: colors,
                borderWidth: 1
            }
        ]
    },
    options: {
        scales: {
            x: {
                position: "bottom",
                grid: {
                    display: false
                }
            },
            y: {
                beginAtZero: true
            }
        },
        plugins: {
            datalabels: {
                anchor: "end",
                align: "top",
                formatter: function(value) {
                    return value;
                }
            },
            legend: {
            display: false // 범례를 숨김
            }
        }
    },
    plugins: [ChartDataLabels]
});