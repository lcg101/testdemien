document.addEventListener("DOMContentLoaded", function() {
    const rows = document.querySelectorAll("tbody tr");
    rows.forEach(function(row) {
        const serverNameCell = row.querySelector("td:nth-child(1)");
        const basicQuantityCell = row.querySelector("td:nth-child(3)");
        const totalEaCell = row.querySelector("td:nth-child(8)");
        const basicQuantityValue = parseInt(basicQuantityCell.textContent.trim());
        const totalEaValue = parseInt(totalEaCell.textContent.trim());

        // 기본수량의 50% 계산
        const halfBasicQuantity = basicQuantityValue * 0.5;

        // 총수량이 기본수량의 50% 미만일 때 서버명과 총수량의 배경색 변경
        if (totalEaValue < halfBasicQuantity) {
            serverNameCell.style.backgroundColor = "lightcoral";
            totalEaCell.style.backgroundColor = "lightcoral";
        }
    });
});